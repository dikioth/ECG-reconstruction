rsync -Cavz physionet.org::challenge-2010 ./
